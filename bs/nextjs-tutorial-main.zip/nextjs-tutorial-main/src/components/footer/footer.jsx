export const Footer = () => {
  return (
    <footer>
      <p> © 2022 Time to Code - A Project Built with Next.js </p>
    </footer>
  );
};
